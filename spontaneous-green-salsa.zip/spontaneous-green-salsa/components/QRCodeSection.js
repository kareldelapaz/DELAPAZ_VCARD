import React from 'react';
import { View, StyleSheet } from 'react-native';
import QRCode from 'react-native-qrcode-svg';
import Section from './Section';
import { widthPercentageToDP as wp } from 'react-native-responsive-screen';

const QRCodeSection = () => {
  return (
    <Section header="QR Code">
      <View style={styles.qrCodeContainer}>
        <QRCode value="https://your-website-link-here.com" size={wp('40%')} />
      </View>
    </Section>
  );
};

const styles = StyleSheet.create({
  qrCodeContainer: {
    alignItems: 'center',
  },
});

export default QRCodeSection;

