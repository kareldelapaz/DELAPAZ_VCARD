import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { widthPercentageToDP as wp } from 'react-native-responsive-screen';

const Section = ({ header, children }) => {
  return (
    <View style={styles.section}>
      {header && <Text style={styles.header}>{header}</Text>}
      {children}
    </View>
  );
};

const styles = StyleSheet.create({
  section: {
    marginBottom: wp('5%'),
  },
  header: {
    fontSize: wp('5%'), // Adjust font size based on screen width
    fontWeight: 'bold',
    marginBottom: wp('2%'),
  },
});

export default Section;

