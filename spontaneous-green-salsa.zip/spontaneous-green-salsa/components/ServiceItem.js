import React from 'react';
import { Text, StyleSheet } from 'react-native';
import { widthPercentageToDP as wp } from 'react-native-responsive-screen';

const ServiceItem = ({ text }) => {
  return <Text style={styles.serviceText}>{text}</Text>;
};

const styles = StyleSheet.create({
  serviceText: {
    fontSize: wp('4%'), // Adjust font size based on screen width
    marginBottom: wp('2%'),
  },
});

export default ServiceItem;

