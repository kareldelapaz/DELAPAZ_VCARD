import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { widthPercentageToDP as wp } from 'react-native-responsive-screen';

const ContactItem = ({ icon, text, onPress }) => {
  return (
    <TouchableOpacity style={styles.contactItem} onPress={onPress}>
      <Icon name={icon} size={20} color="#000" />
      <Text style={styles.contactText}>{text}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  contactItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: wp('2%'),
  },
  contactText: {
    fontSize: wp('4%'), // Adjust font size based on screen width
    marginLeft: wp('2%'),
  },
});

export default ContactItem;
