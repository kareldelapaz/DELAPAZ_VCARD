import React from 'react';
import { StyleSheet, ScrollView, View, Text, Linking, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import QRCode from 'react-native-qrcode-svg';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import Section from './components/Section';
import ContactItem from './components/ContactItem';
import ServiceItem from './components/ServiceItem';
import QRCodeSection from './components/QRCodeSection';

const App = () => {
  return (
    <ScrollView style={styles.container}>
      <Section>
        <Text style={styles.name}>Karel Delapaz</Text>
        <Text style={styles.title}>Frontend Developer</Text>
        <Text style={styles.about}>
          I am a passionate frontend developer with experience in creating dynamic and responsive web applications. I specialize in web design and photography, and I love bringing creative ideas to life.
        </Text>
      </Section>
      <Section header="Contact:">
        <ContactItem icon="envelope" text="delapaz.karel29@gmail.com" onPress={() => Linking.openURL('mailto:delapaz.karel29@gmail.com')} />
        <ContactItem icon="calendar" text="September 29, 2001" onPress={() => Linking.openURL('https://www.google.com/calendar/render?action=TEMPLATE&text=Karel%20Delapaz%27s%20Birthday&dates=20010929T000000Z/20010929T235959Z')} />
        <ContactItem icon="phone" text="09159768403" onPress={() => Linking.openURL('tel:09159768403')} />
      </Section>
      <Section header="Our Services:">
        <ServiceItem text="Web Design" />
        <ServiceItem text="Photography" />
        <ServiceItem text="Videography" />
      </Section>
      <QRCodeSection />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: wp('5%'),
    backgroundColor: '#fff',
  },
  name: {
    fontSize: wp('6%'), // Adjust font size based on screen width
    fontWeight: 'bold',
    textAlign: 'center',
  },
  title: {
    fontSize: wp('4%'), // Adjust font size based on screen width
    textAlign: 'center',
    color: '#777',
  },
  about: {
    fontSize: wp('4%'), // Adjust font size based on screen width
    marginVertical: hp('2%'),
    textAlign: 'center',
  },
});

export default App;

